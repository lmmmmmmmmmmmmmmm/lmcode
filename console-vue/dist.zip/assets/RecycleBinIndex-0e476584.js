import{_ as e,d as c,e as n}from"./index-0878dee8.js";const r={};function t(o,s){return c(),n("div",null," 回收站 ")}const a=e(r,[["render",t]]);export{a as default};
